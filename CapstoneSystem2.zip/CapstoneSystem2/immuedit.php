<?php
    require 'dbcon.php';
    session_start();
    if (isset($_SESSION['bp_id']) && isset($_SESSION['bpname'])) {
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>REF Edit</title>
  </head>
  <body>
    <div class="container mt-5">
        <div class="card-header">
        <h1 class="text-center">Immunization Form
            <a href="indeximmu.php" class="btn btn-danger float-end">Back</a>
        </h1>
        <div>
        <?php
        if(isset($_GET['brgy_resident_id']))
        {
            $brgy_resident_id = mysqli_real_escape_string($con, $_GET['brgy_resident_id']);
            $query = "SELECT * FROM immunization WHERE brgy_resident_id='$brgy_resident_id'";
            $query_run = mysqli_query($con, $query);

            if(mysqli_num_rows($query_run) > 0){

                $immu = mysqli_fetch_array($query_run);

                ?>
        <form class="row g-3" action="immucode.php" method="POST">
        <input type="hidden" name="brgy_resident_id" value="<?= $immu['brgy_resident_id']; ?>">
        <div class="col-md-12">
        <label><strong>For Children</strong></label>
        <br>
        <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="immucat" id="BCG" value=1  <?php if($immu['immucat'] == 1){ echo "checked";}?>>
        <label class="form-check-label" for="BCG">BCG</label>
        </div>
        <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="immucat" id="OPV1" value=2 <?php if($immu['immucat'] == 2){ echo "checked";}?>>
        <label class="form-check-label" for="OPV1">OPV1</label>
        </div>
        <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="immucat" id="OPV2" value=3 <?php if($immu['immucat'] == 3){ echo "checked";}?>>
        <label class="form-check-label" for="OPV2">OPV2</label>
        </div>
        <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="immucat" id="OPV3" value=4 <?php if($immu['immucat'] == 4){ echo "checked";}?>>
        <label class="form-check-label" for="OPV3">OPV3</label>
        </div>
        <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="immucat" id="DPT1" value=5 <?php if($immu['immucat'] == 5){ echo "checked";}?>>
        <label class="form-check-label" for="DPT1">DPT1</label>
        </div>
        <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="immucat" id="DPT2" value=6 <?php if($immu['immucat'] == 6){ echo "checked";}?>>
        <label class="form-check-label" for="DPT2">DPT2</label>
        </div>
        <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="immucat" id="DPT3" value=7 <?php if($immu['immucat'] == 7){ echo "checked";}?>>
        <label class="form-check-label" for="DPT3">DPT3</label>
        </div>
        <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="immucat" id="Measles" value=8 <?php if($immu['immucat'] == 8){ echo "checked";}?>>
        <label class="form-check-label" for="Measles">Measles</label>
        </div>
        <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="immucat" id="HepatitisB1" value=9 <?php if($immu['immucat'] == 9){ echo "checked";}?>>
        <label class="form-check-label" for="HepatitisB1">Hepatitis B1</label>
        </div>
        <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="immucat" id="HepatitisB2" value=10 <?php if($immu['immucat'] == 10){ echo "checked";}?>>
        <label class="form-check-label" for="HepatitisB2">Hepatitis B2</label>
        </div>
        <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="immucat" id="HepatitisB3" value=11 <?php if($immu['immucat'] == 11){ echo "checked";}?>>
        <label class="form-check-label" for="HepatitisB3">Hepatitis B3</label>
        </div>
        <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="immucat" id="HepatitisA" value=12 <?php if($immu['immucat'] == 12){ echo "checked";}?>>
        <label class="form-check-label" for="HepatitisA">Hepatitis A</label>
        </div>
        <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="immucat" id="Varicella" value=13 <?php if($immu['immucat'] == 13){ echo "checked";}?>>
        <label class="form-check-label" for="Varicella">Varicella (Chicken Pox)</label>
        </div>
        <div class="col-md-12">
            <label><strong>For Young Women</strong></label>
            <br>
        <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="immucat" id="HPV" value=14 <?php if($immu['immucat'] == 14){ echo "checked";}?>>
        <label class="form-check-label" for="HPV">HPV</label>
        </div>
        <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="immucat" id="MMR" value=15 <?php if($immu['immucat'] == 15){ echo "checked";}?>>
        <label class="form-check-label" for="MMR">MMR</label>
        </div>
        </div>
        <div class="col-md-12">
            <label><strong>For Pregnant women</strong></label>
            <br>
        <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="immucat" id="Tetanus" value=16 <?php if($immu['immucat'] == 16){ echo "checked";}?>>
        <label class="form-check-label" for="Tetanus">Tetanus Toxoid</label>
        </div>
        <div class="col-md-12">
        <label><strong>For elderly and immunocompromised</strong></label>
        <br>
        <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="immucat" id="pnuemococcal" value=17 <?php if($immu['immucat'] == 17){ echo "checked";}?>>
        <label class="form-check-label" for="pnuemococcal">Pnuemococcal Vaccine</label>
        </div>
        <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="immucat" id="flu" value=18 <?php if($immu['immucat'] == 18){ echo "checked";}?>>
        <label class="form-check-label" for="flu">Flu Vaccine</label>
        </div>
        </div>
        <div class="col-md-12">
        <label for="description" class="form-label" ><strong>Immunization Description</strong></label>
        <textarea class="form-control" id="description" name="immudesc" rows="3" ><?= $immu['immudesc']; ?></textarea>
        </div>
        <div class="col-md-12">
        <label><strong>Status</strong></label>
        <div class="form-check">
        <input class="form-check-input" type="radio" name="immustatus" id="Alive" value=0 <?php if($immu['immustatus'] == 0){ echo "checked";}?>>
        <label class="form-check-label" for="Alive">Alive</label>
        </div>
        <div class="form-check">
        <input class="form-check-input" type="radio" name="immustatus" id="Dead" value=1 <?php if($immu['immustatus'] == 1){ echo "checked";}?>>
        <label class="form-check-label" for="Dead">Dead</label>
        </div>
        <div class="mb-3">
        <br>
        <label><strong>Remarks</strong></label>
        <input type="text" name="immuremarks" class="form-control" value="<?= $immu['immuremarks']; ?>">
        </div>
        </div>
        <div class="d-grid gap-2 col-4 mx-auto">
        <br>
        <button type="submit" name="update_immu" class="btn btn-primary">Done</button>
        
        </div>
    </div>
</form>

                <?php
            }
            else
            {
                echo "<h4>No record Found</h4>";
            }
    
        }   

        ?>
        

        

    </div>











    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

  </body>
</html>
<?php
    }else
    {
        header("Location: loginform.php");
    }
?>
<?php
session_start();
require 'dbcon.php';
if (isset($_SESSION['bp_id']) && isset($_SESSION['bpname'])) {
?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Resident Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  </head>
  <body>
    <div class="container mt-5">
        <h1>Resident Information</h1>
        <?php
            if(isset($_GET['brgy_resident_id']))
            {
                $brgy_resident_id = mysqli_real_escape_string($con, $_GET['brgy_resident_id']);
                
                $query = "SELECT * FROM barangayresident 
                INNER JOIN governmentprogram ON barangayresident.gpid = governmentprogram.gpid 
                WHERE brgy_resident_id='$brgy_resident_id' ";
                $query_run = mysqli_query($con, $query);

                if(mysqli_num_rows($query_run) > 0)
                {
                    $barangayresident = mysqli_fetch_array($query_run);
                    ?>
                <div class="mb-3">
                <label>Resident Name</label>
                <p class="form-control">
                    <?=$barangayresident['residentname'];?>
                </p>
                </div>
                <div class="mb-3">
                <label>TIN</label>
                <p class="form-control">
                    <?=$barangayresident['pin'];?>
                </p>
                 </div>
                 <div class="col-md-6">
                    <label>Civil Status</label>
                    <br>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="civilstatus" id="Single" value="Single" <?php if($barangayresident['civilstatus']=="Single"){ echo "checked";}?> disabled>
                    <label class="form-check-label" for="inlineRadio1">Single</label>
                    </div>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="civilstatus" id="Married" value="Married" <?php if($barangayresident['civilstatus']=="Married"){ echo "checked";}?> disabled>
                    <label class="form-check-label" for="inlineRadio2">Married</label>
                    </div>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="civilstatus" id="Annuled" value="Annuled" <?php if($barangayresident['civilstatus']=="Annuled"){ echo "checked";}?> disabled>
                    <label class="form-check-label" for="inlineRadio3">Annuled</label>
                    </div>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="civilstatus" id="Widowed" value="Widowed" <?php if($barangayresident['civilstatus']=="Widowed"){ echo "checked";}?> disabled>
                    <label class="form-check-label" for="inlineRadio4">Widowed</label>
                    </div>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="civilstatus" id="Separated" value="Separated" <?php if($barangayresident['civilstatus']=="Separated"){ echo "checked";}?> disabled>
                    <label class="form-check-label" for="inlineRadio5">Separated</label>
                    </div>
                    <div class="mb-3">
                    <label>Religion</label>
                    <p class="form-control">
                        <?=$barangayresident['religion'];?>
                    </p>
                    </div>
                    <div class="col-md-6">
                    <label>Sex</label>
                    <br>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="sex" id="Male" value="Male" <?php if($barangayresident['sex']=="Male"){ echo "checked";}?> disabled>
                    <label class="form-check-label" for="Male">Male</label>
                    </div>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="sex" id="Female" value="Female" <?php if($barangayresident['sex']=="Female"){ echo "checked";}?> disabled>
                    <label class="form-check-label" for="Female">Female</label>
                    </div>
                    <div class="mb-3">
                <label>Birthdate</label>
                <p class="form-control">
                <?=$barangayresident['birthdate'];?>
                </p>
                </div>
                <div class="mb-3">
                    <label>Family Serial</label>
                    <p class="form-control">
                    <?=$barangayresident['familyserial'];?>
                     </p>
                </div>
                <div class="mb-3">
                    <label>Sitio</label>
                    <p class="form-control">
                    <?=$barangayresident['sitio'];?>
                     </p>
                </div>
                <div class="mb-3">
                    <label>Resident Type</label>
                    <p class="form-control">
                    <?=$barangayresident['residenttype'];?>
                     </p>
                </div>
                <div class="mb-3">
                    <label>Government Program</label>
                    <p class="form-control">
                    <?=$barangayresident['gpdesc'];?>
                     </p>
                </div>
                <div class="col-md-12">
                <label>Educational Attainment</label>
                <br>
                <br>
                <div class="form-check">
                <input class="form-check-input" type="radio" name="educationalattainment" id="College Degree, Post Graduate" value="College Degree, Post Graduate" <?php if($barangayresident['educationalattainment']== "College Degree, Post Graduate"){ echo "checked";}?> disabled>
                <label class="form-check-label" for="inlineRadio6">College Degree, Post Graduate</label>
                </div>
                <div class="form-check">
                <input class="form-check-input" type="radio" name="educationalattainment" id="High School" value="High School" <?php if($barangayresident['educationalattainment']== "High School"){ echo "checked";}?> disabled>
                <label class="form-check-label" for="inlineRadio7">High School</label>
                </div>
                <div class="form-check">
                <input class="form-check-input" type="radio" name="educationalattainment" id="Elementary" value="Elementary" <?php if($barangayresident['educationalattainment']== "Elementary"){ echo "checked";}?> disabled>
                <label class="form-check-label" for="inlineRadio8">Elementary</label>
                </div>
                <div class="form-check">
                <input class="form-check-input" type="radio" name="educationalattainment" id="Vocational" value="Vocational" <?php if($barangayresident['educationalattainment']== "Vocational"){ echo "checked";}?> disabled>
                <label class="form-check-label" for="inlineRadio9">Vocational</label>
                </div>
                <div class="form-check">
                <input class="form-check-input" type="radio" name="educationalattainment" id="No Schooling" value="No Schooling" <?php if($barangayresident['educationalattainment']== "No Schooling"){ echo "checked";}?> disabled>
                <label class="form-check-label" for="inlineRadio10">No Schooling</label>
                </div>
                <br>
                </div>

                

                    <?php
                }
                else
                {
                    echo "<h4>No Such Id Found</h4>";

                }
            }

        ?>

        



            
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>
<?php
    }else
    {
        header("Location: loginform.php");
    }
?>


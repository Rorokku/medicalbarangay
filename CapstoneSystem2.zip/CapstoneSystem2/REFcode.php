<?php
require 'dbcon.php';
session_start();

if(isset($_POST['update_ref']))
{
    $brgy_resident_id = mysqli_real_escape_string($con, $_POST['brgy_resident_id']);

    $bloodpressure = mysqli_real_escape_string($con, $_POST['bloodpressure']);
    $examinationdate = date('Y-m-d', strtotime($_POST['examinationdate']));
    $heartrate = mysqli_real_escape_string($con, $_POST['heartrate']);
    $restrate = mysqli_real_escape_string($con, $_POST['restrate']);
    $height = mysqli_real_escape_string($con, $_POST['height']);
    $weight = mysqli_real_escape_string($con, $_POST['weight']);
    $skin = mysqli_real_escape_string($con, $_POST['skin']);


    $query = "UPDATE ref SET examinationdate='$examinationdate', bloodpressure='$bloodpressure',
    heartrate='$heartrate', restrate='$restrate',height='$height', weight='$weight', skin='$skin'
    WHERE brgy_resident_id='$brgy_resident_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION;
        header("Location: indexref.php");
        exit(0);

    }
    else
    {
        $_SESSION;
        header("Location: indexref.php");
        exit(0);
    }
}






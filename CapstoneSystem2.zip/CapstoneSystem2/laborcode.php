<?php
require 'dbcon.php';
session_start();
if(isset($_SESSION['bp_id']) && isset($_SESSION['bpname'])) {

if(isset($_POST['update_labor']))
{
    $brgy_resident_id = mysqli_real_escape_string($con, $_GET['brgy_resident_id']);
    $id = $_SESSION['bp_id'];

    $laborbp = mysqli_real_escape_string($con, $_POST['laborbp']);
    $labortemp = mysqli_real_escape_string($con, $_POST['labortemp']);
    $laborhr = mysqli_real_escape_string($con, $_POST['laborhr']);
    $laborrr = mysqli_real_escape_string($con, $_POST['laborrr']);
    $remarks = mysqli_real_escape_string($con, $_POST['remarks']);


    $query = "UPDATE labor SET laborbp='$laborbp', labortemp='$labortemp',laborhr='$laborhr',laborrr='$laborrr',remarks='$remarks'
    WHERE brgy_resident_id='$brgy_resident_id' AND bp_id = $id";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION;
        header("Location: indexlabor.php");
        exit(0);

    }
    else
    {
        $_SESSION;
        header("Location: indexlabor.php");
        exit(0);
    }
}
?>
<?php
}else{
    header("Location:loginform.php");
}

?>




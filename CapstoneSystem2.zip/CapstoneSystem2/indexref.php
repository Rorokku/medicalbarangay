<?php
session_start();
require 'dbcon.php';
if (isset($_SESSION['bp_id']) && isset($_SESSION['bpname'])) {



?>



<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="stylesheet" href="style1.css">
</head>
<body>
<div class="sidebar">
<div class="container">
    <a class="navbar-brand" href="#">Navbar</a>
  </div>
  <a href="profile.php">Dashboard</a>
  <a class="active" href="indexref.php">REF</a>
  <a href="indexprenatal.php">Prenatal</a>
  <a href="indexlabor.php">Labor</a>
  <a href="indeximmu.php">Immunization</a>
  <a href="indexcheckup.php">Medical Checkup</a>
  <a href="logout.php">Log out</a>
</div>

<div class="content">
<div class="container mt-5">
         <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>REF FORMS
                        <a href="refresidentform.php" class="btn btn-primary float-end">ADD DATA</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Exam Date</th>
                                <th>Action</th>

                                    </tr>
                            </thead>
                            <tbody>
                            <?php
                            if(isset($_GET['page']))
                            {
                                $page = $_GET['page'];
                            }
                            else
                            {
                                $page = 1;
                            }
                        
                            $num_per_page = 02;
                            $start_from = ($page-1)*02;
                            
                            $query = "SELECT * FROM ref INNER JOIN barangayresident ON ref.brgy_resident_id = barangayresident.brgy_resident_id limit $start_from,$num_per_page";
                            $result = mysqli_query($con,$query);
                            ?>
                            <?php
                            while($ref=mysqli_fetch_assoc($result))
                            {
                                ?>
                                        <tr>
                                            <td><?= $ref['ref_id']; ?></td>
                                            <td><?= $ref['residentname']; ?></td>
                                            <td><?= $ref['examinationdate']; ?></td>
                                            <td>
                                            <a href="REFview.php?brgy_resident_id=<?= $ref['brgy_resident_id']; ?>" class="btn btn-info btn-sm">View</a>
                                            <a href="REFedit.php?brgy_resident_id=<?= $ref['brgy_resident_id']; ?>" class="btn btn-success btn-sm">Edit</a>
                                            </td>
                                    
                                    
                                    </tr>
                                        <?php
                                    }
                             
                                ?>
                            </tbody>
                        </table>
                        <a href="profile.php" class="btn btn-danger float-end">Back</a>
                        <div class ="text-center">
                        <?php 
    
                        $pr_query = "SELECT * from ref ";
                        $pr_result = mysqli_query($con,$pr_query);
                        $total_record = mysqli_num_rows($pr_result );
                        
                        $total_page = ceil($total_record/$num_per_page);

                        if($page>1)
                        {
                            echo "<a href='indexref.php?page=".($page-1)."' class='btn btn-danger'>Previous</a>";
                        }

                        
                        for($i=1;$i<$total_page;$i++)
                        {
                            echo "<a href='indexref.php?page=".$i."' class='btn btn-primary'>$i</a>";
                        }

                        if($i>$page)
                        {
                            echo "<a href='indexref.php?page=".($page+1)."' class='btn btn-danger'>Next</a>";
                        }
                
                ?>
                </div>
                    </div>
                </div>
            </div>
         </div>
    </div>
    </div>

</div>
</body>
</html>
<?php
}else{
  header("Location: loginform.php");
}
?>
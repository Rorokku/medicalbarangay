<?php
require 'dbcon.php';
session_start();
if (isset($_SESSION['bp_id']) && isset($_SESSION['bpname'])) {
?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Resident Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  </head>
  <body>
    <div class="container mt-5">
        <h1>Resident Information</h1>
        <?php
            if(isset($_GET['brgy_resident_id']))
            {
                $brgy_resident_id = mysqli_real_escape_string($con, $_GET['brgy_resident_id']);
                $query = "SELECT * FROM barangayresident
                INNER JOIN governmentprogram ON barangayresident.gpid = governmentprogram.gpid
                INNER JOIN ref ON ref.brgy_resident_id = barangayresident.brgy_resident_id
                WHERE ref.brgy_resident_id = '$brgy_resident_id'";
                $query_run = mysqli_query($con, $query);

                if(mysqli_num_rows($query_run) > 0)
                {
                    $refview = mysqli_fetch_array($query_run);
                    ?>
                <form class="row g-3">
                <div class="col-md-6">
                <label>Resident Name</label>
                <p class="form-control">
                    <?=$refview['residentname'];?>
                </p>
                </div>
                <div class="col-md-6">
                <label>TIN</label>
                <p class="form-control">
                    <?=$refview['pin'];?>
                </p>
                 </div>
                    <div class="col-md-6">
                    <label>Religion</label>
                    <p class="form-control">
                        <?=$refview['religion'];?>
                    </p>
                    </div>
                    <div class="col-md-6">
                <label>Birthdate</label>
                <p class="form-control">
                <?=$refview['birthdate'];?>
                </p>
                </div>
                <div class="col-md-6">
                    <label>Family Serial</label>
                    <p class="form-control">
                    <?=$refview['familyserial'];?>
                     </p>
                </div>
                <div class="col-md-6">
                    <label>Sitio</label>
                    <p class="form-control">
                    <?=$refview['sitio'];?>
                     </p>
                </div>
                <div class="col-md-6">
                    <label>Resident Type</label>
                    <p class="form-control">
                    <?=$refview['residenttype'];?>
                     </p>
                </div>
                <div class="col-md-6">
                    <label>Government Program</label>
                    <p class="form-control">
                    <?=$refview['gpdesc'];?>
                     </p>
                </div>
                <div class="col-md-12">
                    <label>Sex</label>
                    <br>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="sex" id="Male" value="Male" <?php if($refview['sex']=="Male"){ echo "checked";}?> disabled>
                    <label class="form-check-label" for="Male">Male</label>
                    </div>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="sex" id="Female" value="Female" <?php if($refview['sex']=="Female"){ echo "checked";}?> disabled>
                    <label class="form-check-label" for="Female">Female</label>
                    </div>
                <div class="col-md-12">
                    <label>Civil Status</label>
                    <br>
                    <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="civilstatus" id="Single" value="Single" <?php if($refview['civilstatus']=="Single"){ echo "checked";}?> disabled>
                    <label class="form-check-label" for="inlineRadio1">Single</label>
                    </div>
                    <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="civilstatus" id="Married" value="Married" <?php if($refview['civilstatus']=="Married"){ echo "checked";}?> disabled>
                    <label class="form-check-label" for="inlineRadio2">Married</label>
                    </div>
                    <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="civilstatus" id="Annuled" value="Annuled" <?php if($refview['civilstatus']=="Annuled"){ echo "checked";}?> disabled>
                    <label class="form-check-label" for="inlineRadio3">Annuled</label>
                    </div> 
                    <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="civilstatus" id="Widowed" value="Widowed" <?php if($refview['civilstatus']=="Widowed"){ echo "checked";}?> disabled>
                    <label class="form-check-label" for="inlineRadio4">Widowed</label>
                    </div>
                    <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="civilstatus" id="Separated" value="Separated" <?php if($refview['civilstatus']=="Separated"){ echo "checked";}?> disabled>
                    <label class="form-check-label" for="inlineRadio5">Separated</label>
                    </div>
                <div class="col-md-12">
                <label>Educational Attainment</label>
                <div class="form-check">
                <input class="form-check-input" type="radio" name="educationalattainment" id="College Degree, Post Graduate" value="College Degree, Post Graduate" <?php if($refview['educationalattainment']=="College Degree, Post Graduate"){ echo "checked";}?> disabled>
                <label class="form-check-label" for="inlineRadio6">College Degree, Post Graduate</label>
                </div>
                <div class="form-check">
                <input class="form-check-input" type="radio" name="educationalattainment" id="High School" value="High School" <?php if($refview['educationalattainment']=="High School"){ echo "checked";}?> disabled>
                <label class="form-check-label" for="inlineRadio7">High School</label>
                </div>
                <div class="form-check">
                <input class="form-check-input" type="radio" name="educationalattainment" id="Elementary" value="Elementary" <?php if($refview['educationalattainment']=="Elementary"){ echo "checked";}?> disabled>
                <label class="form-check-label" for="inlineRadio8">Elementary</label>
                </div>
                <div class="form-check">
                <input class="form-check-input" type="radio" name="educationalattainment" id="Vocational" value="Vocational" <?php if($refview['educationalattainment']=="Vocational"){ echo "checked";}?> disabled>
                <label class="form-check-label" for="inlineRadio9">Vocational</label>
                </div>
                <div class="form-check">
                <input class="form-check-input" type="radio" name="educationalattainment" id="No Schooling" value="No Schooling" <?php if($refview['educationalattainment']=="No Schooling"){ echo "checked";}?> disabled>
                <label class="form-check-label" for="inlineRadio10">No Schooling</label>
                </div>
                <br>
                </form>
                <form class="row g-3">
                <div class="col-md-6">
                <label>Examination Date</label>
                <input type="date" class="form-control" name="examinationdate" value="<?= $refview['examinationdate']; ?>">
                </div>
                <div class="col-md-6">
                    <label>Blood Pressure</label>
                    <input type="text" class="form-control" name="bloodpressure" value="<?= $refview['bloodpressure']; ?>">
                </div>
                <div class="col-md-6">
                    <label>Heart Rate</label>
                    <input type="text" class="form-control" name="heartrate" value="<?= $refview['heartrate']; ?>">
                </div>
                <div class="col-md-6">
                    <label>Rest Rate</label>
                    <input type="text" class="form-control" name="restrate" value="<?= $refview['restrate']; ?>">
                </div>
                <div class="col-md-6">
                    <label>Height</label>
                    <input type="text" class="form-control" name="height" value="<?= $refview['height']; ?>">
                </div>
                <div class="col-md-6">
                    <label>Weight</label>
                    <input type="text" class="form-control" name="weight" value="<?= $refview   ['weight']; ?>">
                </div>
                <div class="col-md-12">
                <label>Skin</label>
                <div class="form-check">
                <input class="form-check-input" type="radio" name="skin" id="Pallor" value=1 <?php if($refview['skin'] == 1){ echo "checked";}?>>
                <label class="form-check-label" for="Pallor">
                    Pallor
                </label>
                </div>
                <div class="form-check">
                <input class="form-check-input" type="radio" name="skin" id="Rashes" value=2 <?php if($refview['skin'] == 2){ echo "checked";}?>>
                <label class="form-check-label" for="Rashes">
                    Rashes
                </label>
                </div>
                <div class="form-check">
                <input class="form-check-input" type="radio" name="skin" id="Jaundice" value=3 <?php if($refview['skin'] == 3){ echo "checked";}?>>
                <label class="form-check-label" for="Jaundice">
                    Jaundice
                </label>
                </div>
                <div class="form-check">
                <input class="form-check-input" type="radio" name="skin" id="Good Skin Turgor" value=4 <?php if($refview['skin'] == 4){ echo "checked";}?>>
                <label class="form-check-label" for="Good Skin Turgor">
                    Good Skin Turgor
                </label>
                
            </div>
                </div>
                </form>
                <a href="indexref.php" class="btn btn-danger float-end">Back</a>

                

                    <?php
                }
                else
                {
                    echo "<h4>No Such Id Found</h4>";

                }
            }

        ?>

        



            
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>
<?php
}else{
    header("Location:loginform.php");
}

?>


<?php
session_start();
require 'dbcon.php';

if(isset($_POST['delete_form']))
{
    $brgy_resident_id = mysqli_real_escape_string($con, $_POST['delete_form']);

    $query = "DELETE FROM barangayresident WHERE brgy_resident_id='$brgy_resident_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {



        $_SESSION;
        header("Location: indexresident.php");
        exit(0);
    }
    else
    {
        $_SESSION;
        header("Location: indexresident.php");
        exit(0);
    }
}







if(isset($_POST['resident_update']))
{
    $brgy_resident_id = mysqli_real_escape_string($con, $_POST['brgy_resident_id']);
    $residentname = mysqli_real_escape_string($con, $_POST['residentname']);
    $pin = mysqli_real_escape_string($con, $_POST['pin']);
    $sex = mysqli_real_escape_string($con, $_POST['sex']);
    $civilstatus = mysqli_real_escape_string($con, $_POST['civilstatus']);
    $religion = mysqli_real_escape_string($con, $_POST['religion']);
    $birthdate = date('Y-m-d', strtotime($_POST['birthdate']));
    $familyserial = mysqli_real_escape_string($con, $_POST['familyserial']);
    $sitio = mysqli_real_escape_string($con, $_POST['sitio']);
    $residenttype = mysqli_real_escape_string($con, $_POST['residenttype']);
    $gpdesc = mysqli_real_escape_string($con, $_POST['gpdesc']);

    $educationalattainment = mysqli_real_escape_string($con, $_POST['educationalattainment']);
    $query = "UPDATE barangayresident INNER JOIN governmentprogram ON barangayresident.gpid = governmentprogram.gpid 
    SET residentname='$residentname', pin='$pin', sex='$sex', civilstatus='$civilstatus', religion='$religion',
    birthdate='$birthdate',familyserial='$familyserial',sitio='$sitio',residenttype='$residenttype',gpdesc='$gpdesc', educationalattainment='$educationalattainment'
    WHERE brgy_resident_id='$brgy_resident_id'";
    $query_run = mysqli_query($con, $query);


    if($query_run)
    {
        $_SESSION;
        header("Location: indexresident.php");
        exit(0);

    }
    else
    {
        $_SESSION;
        header("Location: indexresident.php");
        exit(0);
    }
}










?>
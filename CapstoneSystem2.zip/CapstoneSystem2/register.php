<?php
require 'dbcon.php';

if(isset($_POST['reg_save']))
{
    $bptname = mysqli_real_escape_string($con, $_POST['bptname']);

    $sqlbpt = "INSERT INTO baranagaypostitiontype  (bptname) VALUES ('$bptname')";
    $resultbpt = mysqli_query($con, $sqlbpt);

    $bpt_id = mysqli_insert_id($con);
    $bpname = mysqli_real_escape_string($con, $_POST['bpname']);
    $bppass = mysqli_real_escape_string($con, $_POST['bppass']);
    $workername = mysqli_real_escape_string($con, $_POST['workername']);
    $bpstatus = mysqli_real_escape_string($con, $_POST['bpstatus']);

    $sqlbp = "INSERT INTO barangaypersonel (bpt_id,bpname,bppass,workername,bpstatus) VALUES 
    ('$bpt_id','$bpname','$bppass','$workername','$bpstatus')";

    $query_run = mysqli_query($con, $sqlbp);
   


    if($query_run)
    {
        $_SESSION;
        header("Location: loginform.php");
        exit(0);

    }
    else
    {
        $_SESSION;
        header("Location: loginform.php");
        exit(0);
    }
}
?>
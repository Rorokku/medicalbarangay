<?php
require 'dbcon.php';
session_start();

if(isset($_POST['bpname']) && isset($_POST['bppass'])){

	function validate($data){
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}
	$bpid = validate($_POST['bp_id']);
	$bpname = validate($_POST['bpname']);
	$bppass = validate($_POST['bppass']);

	if (empty($bpname)){
		header("Location: loginform.php?error=Username is required");
		exit(); 
	}else if(empty($bppass)){
		header("Location: loginform.php?error=Password is required");
		exit(); 
	}else{
		$sql = "SELECT * FROM barangaypersonel WHERE bpname='$bpname' AND bppass='$bppass'";
		$result = mysqli_query($con, $sql);

		if(mysqli_num_rows($result)  > 0)
		{
			$row = mysqli_fetch_assoc($result);
			if($row['bpname'] === $bpname && $row['bppass'] === $bppass) {
				$_SESSION['bpname'] = $row['bpname'];
				$_SESSION['workername'] = $row['workername'];
				$_SESSION['bpt_id'] = $row['bpt_id'];
				$_SESSION['bp_id'] = $row['bp_id'];
				$bpid = $row['bp_id'];
				$sql = "INSERT INTO activitylog (bp_id) VALUES ($bpid)";
				$query_sql = mysqli_query($con, $sql);

				header("Location: profile.php");
				exit(); 
				
			}
			
		}else{
			header("Location: loginform.php?error=Incorrect Username or Password");
			exit(); 
		}
		
	}

}else{
	header("Location: loginform.php");
	exit();
}
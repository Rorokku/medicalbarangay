<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous" />

    <title>Programs</title>
  </head>
  <body>
    <section>
    <nav class="navbar navbar-expand-lg navbar-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="home.php"><strong>Back</strong></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    
</nav>
      <div class="container mt-5 pt-5">
        <div class="row">
          <div class="col-12 col-sm-7 col-md-6 m-auto">
            <div class="card border-0 shadow">
              <div class="card-body">
                    <h1 class="text-center">SELECT PROGRAMS</h1>
                <form action="">
                  
                  <div class="text-center mt-3">
                  <div class="d-grid gap-2">
                  <a href="indexref.php" class="btn btn-primary" tabindex="-1" role="button" aria-disabled="true">Resident Examination Findings</a>
                  <a href="survey-form1.php" class="btn btn-primary" tabindex="-1" role="button" aria-disabled="true">Prenatal</a>
                  <a href="survey-form2.php" class="btn btn-primary" tabindex="-1" role="button" aria-disabled="true">Labor</a>
                  <a href="survey-form3.php" class="btn btn-primary" tabindex="-1" role="button" aria-disabled="true">Immunization</a>
                  <a href="survey-form4.php" class="btn btn-primary" tabindex="-1" role="button" aria-disabled="true">Checkup</a>
                
                    </div>                     
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>
  </body>
</html>

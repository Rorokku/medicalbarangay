<?php
session_start();
require 'dbcon.php';
if (isset($_SESSION['bp_id']) && isset($_SESSION['bpname'])) {



?>



<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="stylesheet" href="style1.css">
</head>
<body>
<div class="sidebar">
<div class="container">
    <a class="navbar-brand" href="#">Navbar</a>
  </div>
  
  <a class="active" href="#home">Dashboard</a>
  <a href="indexref.php">REF</a>
  <a href="indexprenatal.php">Prenatal</a>
  <a href="indexlabor.php">Labor</a>
  <a href="indeximmu.php">Immunization</a>
  <a href="indexcheckup.php">Medical Checkup</a>
  <a href="logout.php">Log out</a>
</div>

<div class="content">
<div class="container mt-5">
         <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>RESIDENT FORMS
                        <a href="profile.php" class="btn btn-danger float-end">Back</a>
                        </h4>
                    </div>
                    &nbsp;
                    <div class="input-group">
                    &nbsp;&nbsp;&nbsp;&nbsp;<input type="search" id="myInput"class="form-control rounded" placeholder="Search" aria-label="Search" aria-describedby="search-addon" />
                    <button type="button" class="btn btn-outline-primary">search</button>&nbsp;&nbsp;&nbsp;&nbsp;
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                <th>Resident Name</th>
                                <th>PIN</th>
                                <th>Sex</th>
                                <th>Civil Status</th>
                                <th>Action</th>
                                    </tr>
                            </thead>
                            <tbody id="myTable">
                             <?php
                            if(isset($_GET['page']))
                            {
                                $page = $_GET['page'];
                            }
                            else
                            {
                                $page = 1;
                            }
                        
                            $num_per_page = 04;
                            $start_from = ($page-1)*04;
                            
                            $query = "SELECT * FROM barangayresident limit $start_from,$num_per_page";
                            $result = mysqli_query($con,$query);
                            ?>
                            <?php

                                while($barangayresident=mysqli_fetch_assoc($result))
                                {
                                        ?>
                                        <tr>
                                            <td><?= $barangayresident['residentname']; ?></td>
                                            <td><?= $barangayresident['pin']; ?></td>
                                            <td><?= $barangayresident['sex']; ?></td>
                                            <td><?= $barangayresident['civilstatus']; ?></td>
                                            <td>
                                            <a href="residentview.php?brgy_resident_id=<?= $barangayresident['brgy_resident_id']; ?>" class="btn btn-info btn-sm">View</a>
                                                    
                                                    <a href="residentedit.php?brgy_resident_id=<?= $barangayresident['brgy_resident_id']; ?>" class="btn btn-success btn-sm">Edit</a>

                                    </td>
                                    </tr>
                                        <?php
                                    }
                                ?>
                                
                            </tbody>
                        </table>
                        
                        <div class ="text-center">
                        <?php 
                        
                        $pr_query = "SELECT * from barangayresident ";
                        $pr_result = mysqli_query($con,$pr_query);
                        $total_record = mysqli_num_rows($pr_result );
                        
                        $total_page = ceil($total_record/$num_per_page);

                        if($page>1)
                        {
                            echo "<a href='profile.php?page=".($page-1)."' class='btn btn-danger'>Previous</a>";
                        }

                        
                        for($i=1;$i<$total_page;$i++)
                        {
                            echo "<a href='profile.php?page=".$i."' class='btn btn-primary'>$i</a>";
                        }

                        if($i>$page)
                        {
                            echo "<a href='profile.php?page=".($page+1)."' class='btn btn-danger'>Next</a>";
                        }
                
                ?>
                        
               
                   

                    </div>
                    </div>
                </div>
            </div>
         </div>
    </div>
 <section>
    <div class="dashboard_card">
      <h3>Prenatal</h3>
      <p><b><?php
      $sql = "SELECT * FROM prenatal WHERE bpstatus=0";
      $query = mysqli_query($con, $sql);
      echo mysqli_num_rows($query);
      ?></b></p>
    </div>
    <div class="dashboard_card">
      <h3>REF</h3>
      
    </div>
    <div class="dashboard_card">
      <h3>Labor</h3>
    </div>
    <div class="dashboard_card">
      <h3>Immunization</h3>
    </div>
    <div class="dashboard_card">
      <h3>Medical Checkup</h3>
    </div>
</section>

</div>
</body>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
<?php
}else{
  header("Location: loginform.php");
}
?>
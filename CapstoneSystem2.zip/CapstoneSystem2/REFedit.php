<?php
    require 'dbcon.php';
    session_start();
    if (isset($_SESSION['bp_id']) && isset($_SESSION['bpname'])) {
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>REF Edit</title>
  </head>
  <body>
    <div class="container mt-5">
        <h1 class="text-center">Resident Examination Findings Form</h1>
        <?php
        if(isset($_GET['brgy_resident_id']))
        {
            $brgy_resident_id = mysqli_real_escape_string($con, $_GET['brgy_resident_id']);
            $query = "SELECT * FROM ref WHERE brgy_resident_id='$brgy_resident_id'";
            $query_run = mysqli_query($con, $query);

            if(mysqli_num_rows($query_run) > 0){

                $ref = mysqli_fetch_array($query_run);

                ?>
                <form class="row g-3" action="REFcode.php" method="POST">
                <input type="hidden" name="brgy_resident_id" value="<?= $ref['brgy_resident_id']; ?>">

            <div class="col-md-12">
                <label>Examination Date</label>
                <input type="date" class="form-control" name="examinationdate" value="<?= $ref['examinationdate']; ?>">
            </div>
            <div class="col-md-6">
                <label>Blood Pressure</label>
                <input type="text" class="form-control" name="bloodpressure" value="<?= $ref['bloodpressure']; ?>">
            </div>
            <div class="col-md-6">
                <label>Heart Rate</label>
                <input type="text" class="form-control" name="heartrate" value="<?= $ref['heartrate']; ?>">
            </div>
            <div class="col-md-6">
                <label>Rest Rate</label>
                <input type="text" class="form-control" name="restrate" value="<?= $ref['restrate']; ?>">
            </div>
            <div class="col-md-6">
                <label>Height</label>
                <input type="text" class="form-control" name="height" value="<?= $ref['height']; ?>">
            </div>
            <div class="col-md-6">
                <label>Weight</label>
                <input type="text" class="form-control" name="weight" value="<?= $ref['weight']; ?>">
            </div>
            <div class="col-md-12">
            <label>Skin</label>
            <div class="form-check">
            <input class="form-check-input" type="radio" name="skin" id="Pallor" value=1 <?php if($ref['skin'] == 1){ echo "checked";}?>>
            <label class="form-check-label" for="Pallor">Pallor</label>
            </div>
            <div class="form-check">
            <input class="form-check-input" type="radio" name="skin" id="Rashes" value=2 <?php if($ref['skin'] == 2){ echo "checked";}?>>
            <label class="form-check-label" for="Rashes">Rashes</label>
            </div>
            <div class="form-check">
            <input class="form-check-input" type="radio" name="skin" id="Jaundice" value=3 <?php if($ref['skin'] == 3){ echo "checked";}?>>
            <label class="form-check-label" for="Jaundice">Jaundice</label>
            </div>
            <div class="form-check">
            <input class="form-check-input" type="radio" name="skin" id="Good Skin Turgor" value=4 <?php if($ref['skin'] == 4){ echo "checked";}?>>
            <label class="form-check-label" for="Good Skin Turgor">Good Skin Turgor</label>
            </div>
            <div class="d-grid gap-2 col-4 mx-auto">
                <br>
                <button type="submit" name="update_ref" class="btn btn-primary">Done</a>
                </div>
            </div>
    </form>
                <?php
            }
            else
            {
                echo "<h4>No record Found</h4>";
            }
    
        }   

        ?>
        

        

    </div>











    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

  </body>
</html>
<?php
}else{
    header("Location:loginform.php");
}

?>


<?php
require 'dbcon.php';
session_start();
if (isset($_SESSION['bp_id']) && isset($_SESSION['bpname'])) {
?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Resident Edit</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  </head>
  <body>
    <div class="container mt-5">
        <h1>Resident Information</h1>
        <?php
        if(isset($_GET['brgy_resident_id']))
        {
            $brgy_resident_id = mysqli_real_escape_string($con, $_GET['brgy_resident_id']);
            $query = "SELECT * FROM barangayresident
            INNER JOIN governmentprogram ON barangayresident.gpid = governmentprogram.gpid 
             WHERE brgy_resident_id='$brgy_resident_id'";
            $query_run = mysqli_query($con, $query);

            if(mysqli_num_rows($query_run) > 0)
            {
                
                
                $row = mysqli_fetch_array($query_run);
                
                ?>

            <form class="row g-3" action="residentcode.php" method="POST">
                <input type="hidden" name="brgy_resident_id" value="<?= $row['brgy_resident_id']; ?>">
                
            <div class="col-md-6">
                <label>Resident Name</label>
                <input type="text" class="form-control" value="<?= $row['residentname']; ?>" name="residentname" >
            </div>
            <div class="col-md-6">
                <label>TIN</label>
                <input type="text" class="form-control" value="<?= $row['pin']; ?>" name="pin">
            </div>
            <div class="col-md-6">
            <label>Civil Status</label>
            <br>
            <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="civilstatus" id="Single" value="Single" <?php if($row['civilstatus']=="Single"){ echo "checked";}?>>
            <label class="form-check-label" for="inlineRadio1">Single</label>
            </div>
            <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="civilstatus" id="Married" value="Married" <?php if($row['civilstatus']=="Married"){ echo "checked";}?>>
            <label class="form-check-label" for="inlineRadio2">Married</label>
            </div>
            <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="civilstatus" id="Annuled" value="Annuled" <?php if($row['civilstatus']=="Annuled"){ echo "checked";}?>>
            <label class="form-check-label" for="inlineRadio3">Annuled</label>
            </div>
            <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="civilstatus" id="Widowed" value="Widowed" <?php if($row['civilstatus']=="Widowed"){ echo "checked";}?>>
            <label class="form-check-label" for="inlineRadio4">Widowed</label>
            </div>
            <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="civilstatus" id="Separated" value="Separated" <?php if($row['civilstatus']=="Separated"){ echo "checked";}?>>
            <label class="form-check-label" for="inlineRadio5">Separated</label>
            </div>
            </div>
            <div class="col-md-6">
                <label>Religion</label>
                <input type="text" class="form-control" value="<?= $row['religion']; ?>" name="religion">
            </div>
            <div class="col-md-6">
            <label>Sex</label>
            <br>
            <div class="form-check">
            <input class="form-check-input" type="radio" name="sex" id="Male" value="Male" <?php if($row['sex']=="Male"){ echo "checked";}?>>
            <label class="form-check-label" for="Male">Male</label>
            </div>
            <div class="form-check">
            <input class="form-check-input" type="radio" name="sex" id="Female" value="Female" <?php if($row['sex']=="Female"){ echo "checked";}?>>
            <label class="form-check-label" for="Female">Female</label>
            </div>
            </div>
            <div class="col-md-6">
                <label>Birthdate</label>
                <input type="date" class="form-control" value="<?= $row['birthdate']; ?>" name="birthdate" >
            </div>
            <div class="col-md-6">
                <label>Family Serial</label>
                <input type="text" class="form-control" name="familyserial" value="<?= $row['familyserial']; ?>">
            </div>
            <div class="col-md-6">
                <label>Sitio</label>
                <input type="text" class="form-control" name="sitio" value="<?= $row['sitio']; ?>">
            </div>
            <div class="col-md-6">
                <label>Resident Type</label>
                <input type="text" class="form-control" name="residenttype" value="<?= $row['residenttype']; ?>">
            </div>
            <div class="col-md-6">
                <label>Government Program</label>
                <input type="text" class="form-control" name="gpdesc" value="<?= $row['gpdesc']; ?>">
            </div>
            <div class="col-md-12">
                <label>Educational Attainment</label>
                <br>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="educationalattainment" id="College Degree, Post Graduate" value="College Degree, Post Graduate" <?php if($row['educationalattainment']=="College Degree, Post Graduate"){ echo "checked";}?>>
                <label class="form-check-label" for="inlineRadio6">College Degree, Post Graduate</label>
                </div>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="educationalattainment" id="High School" value="High School" <?php if($row['educationalattainment']=="High School"){ echo "checked";}?>>
                <label class="form-check-label" for="inlineRadio7">High School</label>
                </div>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="educationalattainment" id="Elementary" value="Elementary" <?php if($row['educationalattainment']=="Elementary"){ echo "checked";}?>>
                <label class="form-check-label" for="inlineRadio8">Elementary</label>
                </div>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="educationalattainment" id="Vocational" value="Vocational" <?php if($row['educationalattainment']=="Vocational"){ echo "checked";}?>>
                <label class="form-check-label" for="inlineRadio9">Vocational</label>
                </div>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="educationalattainment" id="No Schooling" value="No Schooling" <?php if($row['educationalattainment']=="No Schooling"){ echo "checked";}?>>
                <label class="form-check-label" for="inlineRadio10">No Schooling</label>
                </div>
                <br>
                <br>
                <div class="d-grid gap-2 col-4 mx-auto">
                <br>
                <button type="submit" name="resident_update" class="btn btn-primary">Update</button>
                </div>
        </div>
            </form>
                    <?php
            }
            else
            {
                echo "<h4> No such ID found</h4>";
            }
        }
        ?>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>
<?php
    }else
    {
        header("Location: loginform.php");
    }
?>


<?php
require 'dbcon.php';
session_start();
if (isset($_SESSION['bp_id']) && isset($_SESSION['bpname'])) {

if(isset($_POST['labor_save']))
{
    $gpdesc = mysqli_real_escape_string($con, $_POST['gpdesc']);
    $gpquery = "INSERT INTO governmentprogram (gpdesc) VALUES ('$gpdesc')";
    $resultgp = mysqli_query($con, $gpquery);
    
    $gpid = mysqli_insert_id($con);
    $residentname = mysqli_real_escape_string($con, $_POST['residentname']);
    $pin = mysqli_real_escape_string($con, $_POST['pin']);
    $civilstatus = mysqli_real_escape_string($con, $_POST['civilstatus']);
    $religion = mysqli_real_escape_string($con, $_POST['religion']);
    $sex = mysqli_real_escape_string($con, $_POST['sex']);
    $birthdate = date('Y-m-d', strtotime($_POST['birthdate']));
    $familyserial = mysqli_real_escape_string($con, $_POST['familyserial']);
    $sitio = mysqli_real_escape_string($con, $_POST['sitio']);
    $residenttype = mysqli_real_escape_string($con, $_POST['residenttype']);
    $educationalattainment = mysqli_real_escape_string($con, $_POST['educationalattainment']);

    
    $query = "INSERT INTO barangayresident (gpid,residentname,pin,civilstatus,religion,sex,birthdate,familyserial,sitio,residenttype,educationalattainment) VALUES 
    ('$gpid','$residentname','$pin','$civilstatus','$religion','$sex','$birthdate','$familyserial','$sitio','$residenttype','$educationalattainment')";
    $query_run = mysqli_query($con, $query);
    $brgy_resident_id = mysqli_insert_id($con);
    

    

    

    if($query_run)
    {   
        
        $query2 = "INSERT INTO labor (brgy_resident_id,bp_id) VALUES ('$brgy_resident_id','{$_SESSION['bp_id']}')";
        $result = mysqli_query($con, $query2);
        header("Location: indexlabor.php");
        exit(0);

    }
    else
    {
        
        header("Location: indexlabor.php");
        exit(0);
    }
}




?>
<?php
}else{
    header("Location:loginform.php");
}

?>


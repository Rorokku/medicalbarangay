<?php
    require 'dbcon.php';
    session_start();
    if (isset($_SESSION['bp_id']) && isset($_SESSION['bpname'])) {
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  </head>
  <body>
    <div class="container mt-5">
        <h1 class="text-center">Labor Form</h1>
        <?php
        if(isset($_GET['brgy_resident_id'])) 
        {
          $brgy_resident_id = mysqli_real_escape_string($con, $_GET['brgy_resident_id']);
          
          $query = "SELECT * FROM labor WHERE brgy_resident_id='$brgy_resident_id' AND bp_id = {$_SESSION['bp_id']}";
          $query_run = mysqli_query($con, $query);
          
          if(mysqli_num_rows($query_run) > 0) {

            $lbr = mysqli_fetch_array($query_run);
            ?>
        <form class="row g-3" action="laborcode.php?brgy_resident_id=<?php echo $lbr['brgy_resident_id'] ?>.php" method="POST">
        <div class="col-md-12">
            <label><strong>Blood Pressure</strong></label>
            <input type="text" class="form-control" id="name" name="laborbp" placeholder="Enter your Blood Pressure" value="<?= $lbr['laborbp']; ?>" required>
            </div>
            <div class="col-md-12">
            <label><strong>Temperature</strong></label>
            <input type="text" class="form-control" id="name" name="labortemp" placeholder="Enter your Temperature" value="<?= $lbr['labortemp']; ?>" required>
            </div>
            <div class="col-md-12">
            <label><strong>Heart Rate</strong></label>
            <input type="text" class="form-control" id="name" name="laborhr"placeholder="Enter your Heart Rate" value="<?= $lbr['laborhr']; ?>" required>
            </div>
            <div class="col-md-12">
            <label><strong>Rest Rate</strong></label>
            <input type="text" class="form-control" id="name" name="laborrr" placeholder="Enter your Rest Rate" value="<?= $lbr['laborrr']; ?>" required>
            </div>
            <div class="col-md-12">
                <label for="comments" class="form-label"><strong>Remarks</label></strong>
                <textarea class="form-control" id="comments" rows="4" name="remarks"><?=$lbr['remarks'];?></textarea>
            </div>
            <div class="d-grid gap-2 col-4 mx-auto">
                <br>
                <button type="submit" name="update_labor" class="btn btn-primary">Done</button>
                </div>
    </form>
    <?php
          }
          else
          {
              echo "<h4>No Record Found<h4>";
          }
        }
        ?> 
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>
<?php
}else{
    header("Location:loginform.php");
}

?>
<?php
require 'dbcon.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous" />
    <link rel="stylesheet" href="style.css">
  
    <title>Login Form</title>

  </head>
  <body class="header">
    <section>
      <div class="container mt-5 pt-5">
        <div class="row">
          <div class="col-12 col-sm-7 col-md-6 m-auto">
            <div class="card border-0 shadow">
              <div class="card-body">
                <form action="login.php" method="POST">
                  <?php if(isset($_GET['error'])) { 
                    ?>
                    <p class="alert alert-danger" role="alert"><?php echo $_GET['error']; ?></p>
                  <?php 
                  } ?>
                  <input type="text" name="bpname"  class="form-control my-4 py-2" placeholder="Username" />
                  <input type="password" name="bppass"  class="form-control my-4 py-2" placeholder="Password" />
                  <p>Don't have an account? <a href="registerform.php" class="link-info">Register here</a></p>
                  <div class="d-grid gap-2 col-6 mx-auto">
                        <button type="submit" class="btn btn-primary">Login</a>
                    </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>
  </body>
</html>



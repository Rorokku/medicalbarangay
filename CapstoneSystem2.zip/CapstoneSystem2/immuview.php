<?php
require 'dbcon.php';
session_start();
if (isset($_SESSION['bp_id']) && isset($_SESSION['bpname'])) {
?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Resident Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  </head>
  <body>
    <div class="container mt-5">
        <h1>Resident Information</h1>
    
        <?php
            if(isset($_GET['brgy_resident_id']))
            {
                $brgy_resident_id = mysqli_real_escape_string($con, $_GET['brgy_resident_id']);
                $query = "SELECT * FROM barangayresident
                INNER JOIN governmentprogram ON barangayresident.gpid = governmentprogram.gpid
                INNER JOIN immunization ON immunization.brgy_resident_id = barangayresident.brgy_resident_id
                WHERE immunization.brgy_resident_id = '$brgy_resident_id'";
                
                $query_run = mysqli_query($con, $query);

                if(mysqli_num_rows($query_run) > 0)
                {
                    $immuview = mysqli_fetch_array($query_run);
                    ?>
                <form class="row g-3">
                <div class="col-md-6">
                <label>Resident Name</label>
                <p class="form-control">
                    <?=$immuview['residentname'];?>
                </p>
                </div>
                <div class="col-md-6">
                <label>TIN</label>
                <p class="form-control">
                    <?=$immuview['pin'];?>
                </p>
                 </div>
                 
                    <div class="col-md-6">
                    <label>Religion</label>
                    <p class="form-control">
                        <?=$immuview['religion'];?>
                    </p>
                    </div>
                    <div class="col-md-6">
                <label>Birthdate</label>
                <p class="form-control">
                <?=$immuview['birthdate'];?>
                </p>
                </div>
                <div class="col-md-6">
                    <label>Family Serial</label>
                    <p class="form-control">
                    <?=$immuview['familyserial'];?>
                     </p>
                </div>
                <div class="col-md-6">
                    <label>Sitio</label>
                    <p class="form-control">
                    <?=$immuview['sitio'];?>
                     </p>
                </div>
                <div class="col-md-6">
                    <label>Resident Type</label>
                    <p class="form-control">
                    <?=$immuview['residenttype'];?>
                     </p>
                </div>
                <div class="col-md-6">
                    <label>Government Program</label>
                    <p class="form-control">
                    <?=$immuview['gpdesc'];?>
                     </p>
                </div>
                <div class="col-md-12">
                    <label>Sex</label>
                    <br>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="sex" id="Male" value="Male" <?php if($immuview['sex']=="Male"){ echo "checked";}?> disabled>
                    <label class="form-check-label" for="Male">Male</label>
                    </div>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="sex" id="Female" value="Female" <?php if($immuview['sex']=="Female"){ echo "checked";}?> disabled>
                    <label class="form-check-label" for="Female">Female</label>
                    </div>
                <div class="col-md-12">
                    <label>Civil Status</label>
                    <br>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="civilstatus" id="Single" value="Single" <?php if($immuview['civilstatus']=="Single"){ echo "checked";}?> disabled>
                    <label class="form-check-label" for="inlineRadio1">Single</label>
                    </div>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="civilstatus" id="Married" value="Married" <?php if($immuview['civilstatus']=="Married"){ echo "checked";}?> disabled>
                    <label class="form-check-label" for="inlineRadio2">Married</label>
                    </div>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="civilstatus" id="Annuled" value="Annuled" <?php if($immuview['civilstatus']=="Annuled"){ echo "checked";}?> disabled>
                    <label class="form-check-label" for="inlineRadio3">Annuled</label>
                    </div>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="civilstatus" id="Widowed" value="Widowed" <?php if($immuview['civilstatus']=="Widowed"){ echo "checked";}?> disabled>
                    <label class="form-check-label" for="inlineRadio4">Widowed</label>
                    </div>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="civilstatus" id="Separated" value="Separated" <?php if($immuview['civilstatus']=="Separated"){ echo "checked";}?> disabled>
                    <label class="form-check-label" for="inlineRadio5">Separated</label>
                    </div>
                <div class="col-md-12">
                <label>Educational Attainment</label>
                <br>
                <br>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="educationalattainment" id="College Degree, Post Graduate" value="College Degree, Post Graduate" <?php if($immuview['educationalattainment']=="College Degree, Post Graduate"){ echo "checked";}?> disabled>
                <label class="form-check-label" for="inlineRadio6">College Degree, Post Graduate</label>
                </div>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="educationalattainment" id="High School" value="High School" <?php if($immuview['educationalattainment']=="High School"){ echo "checked";}?> disabled>
                <label class="form-check-label" for="inlineRadio7">High School</label>
                </div>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="educationalattainment" id="Elementary" value="Elementary" <?php if($immuview['educationalattainment']=="Elementary"){ echo "checked";}?> disabled>
                <label class="form-check-label" for="inlineRadio8">Elementary</label>
                </div>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="educationalattainment" id="Vocational" value="Vocational" <?php if($immuview['educationalattainment']=="Vocational"){ echo "checked";}?> disabled>
                <label class="form-check-label" for="inlineRadio9">Vocational</label>
                </div>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="educationalattainment" id="No Schooling" value="No Schooling" <?php if($immuview['educationalattainment']=="No Schooling"){ echo "checked";}?> disabled>
                <label class="form-check-label" for="inlineRadio10">No Schooling</label>
                </div>
                <br>
                </div>
                </form>
                <form class ="row g-3">
                <div class="col-md-12">
                <label><strong>For Children</strong></label>
                <br>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="immucat" id="BCG" value=1  <?php if($immuview['immucat'] == 1){ echo "checked";}?> disabled>
                <label class="form-check-label" for="BCG">BCG</label>
                </div>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="immucat" id="OPV1" value=2 <?php if($immuview['immucat'] == 2){ echo "checked";}?> disabled>
                <label class="form-check-label" for="OPV1">OPV1</label>
                </div>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="immucat" id="OPV2" value=3 <?php if($immuview['immucat'] == 3){ echo "checked";}?> disabled> 
                <label class="form-check-label" for="OPV2">OPV2</label>
                </div>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="immucat" id="OPV3" value=4 <?php if($immuview['immucat'] == 4){ echo "checked";}?> disabled>
                <label class="form-check-label" for="OPV3">OPV3</label>
                </div>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="immucat" id="DPT1" value=5 <?php if($immuview['immucat'] == 5){ echo "checked";}?> disabled>
                <label class="form-check-label" for="DPT1">DPT1</label>
                </div>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="immucat" id="DPT2" value=6 <?php if($immuview['immucat'] == 6){ echo "checked";}?> disabled>
                <label class="form-check-label" for="DPT2">DPT2</label>
                </div>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="immucat" id="DPT3" value=7 <?php if($immuview['immucat'] == 7){ echo "checked";}?> disabled>
                <label class="form-check-label" for="DPT3">DPT3</label>
                </div>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="immucat" id="Measles" value=8 <?php if($immuview['immucat'] == 8){ echo "checked";}?> disabled>
                <label class="form-check-label" for="Measles">Measles</label>
                </div>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="immucat" id="HepatitisB1" value=9 <?php if($immuview['immucat'] == 9){ echo "checked";}?>disabled>
                <label class="form-check-label" for="HepatitisB1">Hepatitis B1</label>
                </div>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="immucat" id="HepatitisB2" value=10 <?php if($immuview['immucat'] == 10){ echo "checked";}?>disabled>
                <label class="form-check-label" for="HepatitisB2">Hepatitis B2</label>
                </div>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="immucat" id="HepatitisB3" value=11 <?php if($immuview['immucat'] == 11){ echo "checked";}?>disabled>
                <label class="form-check-label" for="HepatitisB3">Hepatitis B3</label>
                </div>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="immucat" id="HepatitisA" value=12 <?php if($immuview['immucat'] == 12){ echo "checked";}?>disabled>
                <label class="form-check-label" for="HepatitisA">Hepatitis A</label>
                </div>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="immucat" id="Varicella" value=13 <?php if($immuview['immucat'] == 13){ echo "checked";}?>disabled>
                <label class="form-check-label" for="Varicella">Varicella (Chicken Pox)</label>
                </div>
                <div class="col-md-12">
                    <label><strong>For Young Women</strong></label>
                    <br>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="immucat" id="HPV" value=14 <?php if($immuview['immucat'] == 14){ echo "checked";}?>disabled>
                <label class="form-check-label" for="HPV">HPV</label>
                </div>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="immucat" id="MMR" value=15 <?php if($immuview['immucat'] == 15){ echo "checked";}?>disabled>
                <label class="form-check-label" for="MMR">MMR</label>
                </div>
                </div>
                <div class="col-md-12">
                    <label><strong>For Pregnant women</strong></label>
                    <br>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="immucat" id="Tetanus" value=16 <?php if($immuview['immucat'] == 16){ echo "checked";}?>disabled>
                <label class="form-check-label" for="Tetanus">Tetanus Toxoid</label>
                </div>
                <div class="col-md-12">
                <label><strong>For elderly and immunocompromised</strong></label>
                <br>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="immucat" id="pnuemococcal" value=17 <?php if($immuview['immucat'] == 17){ echo "checked";}?>disabled>
                <label class="form-check-label" for="pnuemococcal">Pnuemococcal Vaccine</label>
                </div>
                <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="immucat" id="flu" value=18 <?php if($immuview['immucat'] == 18){ echo "checked";}?>disabled>
                <label class="form-check-label" for="flu">Flu Vaccine</label>
                </div>
                </div>
                <div class="col-md-12">
                <label for="description" class="form-label" ><strong>Immunization Description</strong></label>
                <textarea class="form-control" id="description" name="immudesc" rows="3" ><?= $immuview['immudesc']; ?></textarea>
                </div>
                <div class="col-md-12">
                <label><strong>Status</strong></label>
                <div class="form-check">
                <input class="form-check-input" type="radio" name="immustatus" id="Alive" value=0 <?php if($immuview['immustatus'] == 0){ echo "checked";}?> disabled>
                <label class="form-check-label" for="Alive">Alive</label>
                </div>
                <div class="form-check">
                <input class="form-check-input" type="radio" name="immustatus" id="Dead" value=1 <?php if($immuview['immustatus'] == 1){ echo "checked";}?> disabled>
                <label class="form-check-label" for="Dead">Dead</label>
                </div>
                <div class="mb-3">
                <br>
                <label><strong>Remarks</strong></label>
                <p class="form-control" ><?= $immuview['immuremarks']; ?></p>
                </div>
                <a href="indeximmu.php" class="btn btn-danger float-end">Back</a>
                </form>
                
                </div>
                

                

                    <?php
                }
                else
                {
                    echo "<h4>No Such Id Found</h4>";

                }
            }

        ?>

        



          
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>
<?php
}else{
    header("Location:loginform.php");
}

?>


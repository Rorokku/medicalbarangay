<?php
session_start();
require 'dbcon.php';
if (isset($_SESSION['bp_id']) && isset($_SESSION['bpname'])) {
?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Resident Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  </head>
  <body>
    <div class="container mt-5">
        <a href="indexprenatal.php" class="btn btn-danger float-end">Back</a>
        <h1>Resident Information</h1>
        <form class="row g-3" action="prenatalresidentcode.php" method="POST">
            <input type="hidden" name="brgy_resident_id">
            
            <div class="col-md-6">
                <label>Resident Name</label>
                <input type="text" class="form-control" name="residentname">
            </div>
            <div class="col-md-6">
                <label>TIN</label>
                <input type="text" class="form-control" name="pin">
            </div>
            <div class="col-md-6">
            <label>Civil Status</label>
            <br>
            <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="civilstatus" id="Single" value="Single">
            <label class="form-check-label" for="inlineRadio1">Single</label>
            </div>
            <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="civilstatus" id="Married" value="Married">
            <label class="form-check-label" for="inlineRadio2">Married</label>
            </div>
            <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="civilstatus" id="Annuled" value="Annuled">
            <label class="form-check-label" for="inlineRadio3">Annuled</label>
            </div>
            <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="civilstatus" id="Widowed" value="Widowed">
            <label class="form-check-label" for="inlineRadio4">Widowed</label>
            </div>
            <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="civilstatus" id="Separated" value="Separated">
            <label class="form-check-label" for="inlineRadio5">Separated</label>
            </div>
            </div>
            <div class="col-md-6">
                <label>Religion</label>
                <input type="text" class="form-control" name="religion">
            </div>
            <div class="col-md-6">
            <label>Sex</label>
            <br>
            <div class="form-check">
            <input class="form-check-input" type="radio" name="sex" id="Male" value="Male">
            <label class="form-check-label" for="Male">Male</label>
            </div>
            <div class="form-check">
            <input class="form-check-input" type="radio" name="sex" id="Female" value="Female">
            <label class="form-check-label" for="Female">Female</label>
            </div>
            </div>
            <div class="col-md-6">
                <label>Birthdate</label>
                <input type="date" class="form-control" name="birthdate">
            </div>
            <div class="col-md-6">
                <label>Family Serial</label>
                <input type="text" class="form-control" name="familyserial">
            </div>
            <div class="col-md-6">
                <label>Sitio</label>
                <input type="text" class="form-control" name="sitio">
            </div>
            <div class="col-md-6">
                <label>Resident Type</label>
                <input type="text" class="form-control" name="residenttype">
            </div>
            <div class="col-md-6">
                <label>Government Program</label>
                <input type="text" class="form-control" name="gpdesc">
            </div>
            <div class="col-md-12">
                <label>Educational Attainment</label>
                <br>
                <div class="form-check">
                <input class="form-check-input" type="radio" name="educationalattainment" id="College Degree, Post Graduate" value="College Degree, Post Graduate">
                <label class="form-check-label" for="inlineRadio6">College Degree, Post Graduate</label>
                </div>
                <div class="form-check">
                <input class="form-check-input" type="radio" name="educationalattainment" id="High School" value="High School">
                <label class="form-check-label" for="inlineRadio7">High School</label>
                </div>
                <div class="form-check">
                <input class="form-check-input" type="radio" name="educationalattainment" id="Elementary" value="Elementary">
                <label class="form-check-label" for="inlineRadio8">Elementary</label>
                </div>
                <div class="form-check">
                <input class="form-check-input" type="radio" name="educationalattainment" id="Vocational" value="Vocational">
                <label class="form-check-label" for="inlineRadio9">Vocational</label>
                </div>
                <div class="form-check">
                <input class="form-check-input" type="radio" name="educationalattainment" id="No Schooling" value="No Schooling">
                <label class="form-check-label" for="inlineRadio10">No Schooling</label>
                </div>
                
            <div class="d-grid gap-2 col-4 mx-auto">
            <br>
            <button type="submit" name="prenatal_save" class="btn btn-primary">Next</button>
            </div>
                     
</div>



            </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>
<?php
}else{
    header("Location:loginform.php");
}

?>


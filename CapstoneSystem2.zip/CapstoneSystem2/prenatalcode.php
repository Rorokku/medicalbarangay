<?php
require 'dbcon.php';
session_start();
if(isset($_SESSION['bp_id']) && isset($_SESSION['bpname'])) {

if(isset($_POST['update_prenatal']))
{
    $id = $_SESSION['bp_id'];
    $brgy_resident_id = mysqli_real_escape_string($con, $_GET['brgy_resident_id']);

    $prenataldx = mysqli_real_escape_string($con, $_POST['prenataldx']);
    $prenataldate = date('Y-m-d', strtotime($_POST['prenataldate']));
    $prenatalplan = mysqli_real_escape_string($con, $_POST['prenatalplan']);


    $query = "UPDATE prenatal SET prenataldx='$prenataldx', prenataldate='$prenataldate',prenatalplan='$prenatalplan'
    WHERE brgy_resident_id = '$brgy_resident_id' AND bp_id = $id";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION;
        header("Location: indexprenatal.php");
        exit(0);

    }
    else
    {
        $_SESSION;
        header("Location: indexprenatal.php");
        exit(0);
    }
}
?>
<?php
}else{
    header("Location:loginform.php");
}

?>




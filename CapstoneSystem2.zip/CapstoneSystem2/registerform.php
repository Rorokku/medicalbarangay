<?php
require 'dbcon.php';

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous" />

    <title>Register Form</title>
  </head>
  <body>
    <section>
      <div class="container mt-5 pt-5">
        <div class="row">
          <div class="col-12 col-sm-7 col-md-6 m-auto">
            <div class="card border-0 shadow">
              <div class="card-body">
                <form action="register.php" method="POST">
                  <h3>Register Form</h3>
                  <br>
                  <input type="text" name="workername"  class="form-control my-4 py-2" placeholder="Full Name" />
                  <input type="text" name="bpname"  class="form-control my-4 py-2" placeholder="Username" />
                  <input type="password" name="bppass"  class="form-control my-4 py-2" placeholder="Password" />
                  <input type="text" name="bptname"  class="form-control my-4 py-2" placeholder="Barangay Position" />
                  <div class="d-grid gap-2 col-6 mx-auto">
                        <button type="submit" name="reg_save"class="btn btn-primary">Register</a>
                    </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>
  </body>
</html>



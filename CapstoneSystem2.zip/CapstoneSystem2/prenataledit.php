<?php
    require 'dbcon.php';
    session_start();
    if (isset($_SESSION['bp_id']) && isset($_SESSION['bpname'])) {
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  </head>
  <body>
    <div class="container mt-5">
        
        <h1 class="text-center">Prenatal Form
        <a href="indexprenatal.php" class="btn btn-danger float-end">Back</a>
        </h1>
        <?php
        if(isset($_GET['brgy_resident_id'])) 
        {
          $brgy_resident_id = mysqli_real_escape_string($con, $_GET['brgy_resident_id']);
          
          $query = "SELECT * FROM prenatal WHERE brgy_resident_id='$brgy_resident_id' AND bp_id = {$_SESSION['bp_id']}";
          $query_run = mysqli_query($con, $query);
          
          if(mysqli_num_rows($query_run) > 0) {

            $pre = mysqli_fetch_array($query_run);
            ?>
            <form class="row g-3" action="prenatalcode.php?brgy_resident_id=<?php echo $pre['brgy_resident_id'] ?>" method="POST">
            <div class="col-md-12">
                <label for="comments" class="form-label"><strong>Assessment/Diagnosis</strong></label>
                <textarea class="form-control" id="comments" name="prenataldx" rows="3"><?=$pre['prenataldx'];?></textarea>
            </div>
            <div class="col-md-12">
                <label for="comments" class="form-label"><strong>Plan/Recommendation</label></strong>
                <textarea class="form-control" id="comments" name="prenatalplan" rows="3"><?=$pre['prenatalplan'];?></textarea>
            </div>
            <div class="col-md-12">
                <label class="control-label" for="date">
                <strong>Date</strong>
                </label>
                <input class="form-control" id="date" name="prenataldate" type="date" value="<?=$pre['prenataldate'];?>">
            </div>
            <div class="d-grid gap-2 col-4 mx-auto">
            <br>
            <button type="submit" name="update_prenatal" class="btn btn-primary">Done</button>
            </div>
</form>
            <?php
          }
          else
          {
              echo "<h4>No Record Found<h4>";
          }
        }
        ?> 
    </div>




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>
<?php
}else{
    header("Location:loginform.php");
}

?>
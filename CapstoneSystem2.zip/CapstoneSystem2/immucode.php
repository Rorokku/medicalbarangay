<?php
 session_start();
 require 'dbcon.php';

 if(isset($_POST['update_immu']))
 {
    $brgy_resident_id = mysqli_real_escape_string($con, $_POST['brgy_resident_id']);
    $bhp_id = mysqli_real_escape_string($con, $_POST['bhp_id']);
    $immucat = mysqli_real_escape_string($con, $_POST['immucat']);
    $immustatus = mysqli_real_escape_string($con, $_POST['immustatus']);
    $immudesc = mysqli_real_escape_string($con, $_POST['immudesc']);
    $immuremarks = mysqli_real_escape_string($con, $_POST['immuremarks']);
    
    
 
    $query = "UPDATE immunization SET immucat='$immucat',immustatus='$immustatus',immudesc='$immudesc',immuremarks='$immuremarks'
    WHERE brgy_resident_id='$brgy_resident_id' ";

    $query_run = mysqli_query($con, $query);
    if($query_run)
    {
        
        header("Location: indeximmu.php");
        exit(0);
    }
    else
    {
        $_SESSION;
        header("Location: indeximmu.php");
        exit(0);
    }

}





?>
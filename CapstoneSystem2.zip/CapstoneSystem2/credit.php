<?php
    require 'dbcon.php';
    session_start();
    if (isset($_SESSION['bp_id']) && isset($_SESSION['bpname'])) {
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Medical Checkup Edit</title>
  </head>
  <body>
    <div class="container mt-5">
        <h1 class="text-center">Resident Examination Findings Form</h1>
        <?php
        if(isset($_GET['brgy_resident_id']))
        {
            $brgy_resident_id = mysqli_real_escape_string($con, $_GET['brgy_resident_id']);
            $query = "SELECT * FROM medicalcheckup WHERE brgy_resident_id='$brgy_resident_id'";
            $query_run = mysqli_query($con, $query);

            if(mysqli_num_rows($query_run) > 0){

                $mdcedit = mysqli_fetch_array($query_run);

                ?>
                <form class="row g-3" action="crcode.php" method="POST">
                <input type="hidden" name="brgy_resident_id" value="<?= $mdcedit['brgy_resident_id']; ?>">

            <div class="mb-3">
            <br>
            <label for="mdcdesc" class="form-label">Medical Checkup</label>
            <textarea class="form-control" name="mdcdesc" rows="3"><?=$mdcedit['mdcdesc'];?></textarea>
            </div>
            <div class="col-md-6">
                <label>Medical Checkup Date </label>
                <input type="date" class="form-control" name="mdcdate" value="<?= $mdcedit['mdcdate']; ?>">
            </div>
            <div class="col-md-6">
            <label>Status</label>
            <br>
            <div class="form-check">
            <input class="form-check-input" type="radio" name="mdcstatus" id="Alive" value=0 <?php if($mdcedit['mdcstatus'] == 0){ echo "checked";}?>>
            <label class="form-check-label" for="Alive">Alive</label>
            </div>
            <div class="form-check">
            <input class="form-check-input" type="radio" name="mdcstatus" id="Dead" value=1 <?php if($mdcedit['mdcstatus'] == 1){ echo "checked";}?>>
            <label class="form-check-label" for="Dead">Dead</label>
            </div>
            </div>
            <label for="mdcdesc" class="form-label">Medical Checkup Remarks</label>
            <textarea class="form-control" name="mdcremarks" rows="3"><?=$mdcedit['mdcremarks'];?></textarea>
            <div class="d-grid gap-2 col-4 mx-auto">
                <br>
                <button type="submit" name="crf_update" class="btn btn-primary">Update</a>
                </div>
            </div>
    </form>
                <?php
            }
            else
            {

            }
    
        }   

        ?>
        

        

    </div>











    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

  </body>
</html>
<?php
}else{
    header("Location:loginform.php");
}

?>

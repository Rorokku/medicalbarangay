<?php
session_start();
require 'dbcon.php';

if(isset($_POST['delete_form']))
{
    $brgy_resident_id = mysqli_real_escape_string($con, $_POST['delete_form']);

    $query = "DELETE FROM barangayresident WHERE brgy_resident_id='$brgy_resident_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {



        $_SESSION;
        header("Location: indexref.php");
        exit(0);
    }
    else
    {
        $_SESSION;
        header("Location: indexref.php");
        exit(0);
    }
}












if(isset($_POST['ref_save']))
{
    $gpdesc = mysqli_real_escape_string($con, $_POST['gpdesc']);
    $gpquery = "INSERT INTO governmentprogram (gpdesc) VALUES ('$gpdesc')";
    $resultgp = mysqli_query($con, $gpquery);

    $gpid = mysqli_insert_id($con);
    $residentname = mysqli_real_escape_string($con, $_POST['residentname']);
    $pin = mysqli_real_escape_string($con, $_POST['pin']);
    $civilstatus = mysqli_real_escape_string($con, $_POST['civilstatus']);
    $religion = mysqli_real_escape_string($con, $_POST['religion']);
    $sex = mysqli_real_escape_string($con, $_POST['sex']);
    $birthdate = date('Y-m-d', strtotime($_POST['birthdate']));
    $familyserial = mysqli_real_escape_string($con, $_POST['familyserial']);
    $sitio = mysqli_real_escape_string($con, $_POST['sitio']);
    $residenttype = mysqli_real_escape_string($con, $_POST['residenttype']);

    $educationalattainment = mysqli_real_escape_string($con, $_POST['educationalattainment']);


    
    
    
    $query = "INSERT INTO barangayresident (gpid,residentname,pin,civilstatus,religion,sex,birthdate,familyserial,sitio,residenttype,educationalattainment) VALUES 
    ('$gpid','$residentname','$pin','$civilstatus','$religion','$sex','$birthdate','$familyserial','$sitio','$residenttype','$educationalattainment')";
    $query_run = mysqli_query($con, $query);
    $brgy_resident_id = mysqli_insert_id($con);
    
    

    if($query_run)
    {   
        $query2 = "INSERT INTO ref (brgy_resident_id) VALUES ('$brgy_resident_id')";
        $resultref = mysqli_query($con, $query2);
        header("Location: indexref.php");
        exit(0);

    }
    else
    {
        
        header("Location: indexref.php");
        exit(0);
    }
}




?>
